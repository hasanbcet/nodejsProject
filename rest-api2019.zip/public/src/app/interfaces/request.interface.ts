export interface IRequest {
  title: string;
  description: string;
  visit_date: string;
  created_date: string;
  status: string;
  creatorId: string;
  reject_reason: string;
}