export interface IUser {
  name: string;
  mobile: string;
  email: string;
  isAdmin: boolean;
  created_date: string;
}