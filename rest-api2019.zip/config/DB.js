// DB.js
const username = 'boy';
const password = 'X1lk2HVcP8uhO289';


module.exports = {
  DB: `mongodb://localhost/resthub`,
  liveDB: `mongodb+srv://boy:X1lk2HVcP8uhO289@pm-liccb.mongodb.net/test?retryWrites=true`
};